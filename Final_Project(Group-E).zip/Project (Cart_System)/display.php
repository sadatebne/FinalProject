<?php
session_start();
require_once('cart2.php');


$user='root';
$pass='';
$dbn='ecart';


$db = mysqli_connect("localhost", $user, $pass, $dbn);


$sql="select * from mobile";
$sql2="select * from laptop";
$result= mysqli_query($db, $sql);
$result2= mysqli_query($db, $sql2);


if(isset($_POST['remove']))
{
	
	//print_r($_GET['id']);
	if($_GET['action']=='remove'){
	foreach($_SESSION['cart'] as $key=>$value){
		if($value["product_id"]==$_GET["id"]){
			unset($_SESSION['cart'][$key]);
			echo"<script> alert('Product Removed')</script>";
			echo"<script> window.location=display.php </script>";
		}
	}
		
	}
}

?>

<!DOCTYPE html>
<!html lang ="en">
<head>
<meta charset ="UTF-8">
<title> Shopping Page </title>
<link rel="stylesheet" href="cart.css">
<!--Font Awesome-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

</head>

<body>

<?php
require_once('header.php');
?>

<div class="row px-5">
<div class="col-md-7">
<div class="shopping-cart">
<h6> My cart </h6>
<hr>
<?php
$total=0;
if (isset($_SESSION['cart'])){
$product_id=array_column($_SESSION['cart'],"product_id");
while($row=mysqli_fetch_assoc($result)){
	foreach($product_id as $id){
		if($row['id']==$id){
	
	 C_Element($row['mobile_image'],$row['mobile_name'],$row['mobile_price'],$row['id']);
	// C_Element($row['laptop_image'],$row['laptop_name'],$row['laptop_price']);
	 $total=$total+(int)$row['mobile_price'];
		}
	}
}
while($row=mysqli_fetch_assoc($result2)){
	foreach($product_id as $id){
		if($row['id']==$id){
	
	 //C_Element($row['mobile_image'],$row['mobile_name'],$row['mobile_price']);
	 C_Element($row['laptop_image'],$row['laptop_name'],$row['laptop_price'],$row['id']);
	 $total=$total+(int)$row['laptop_price'];
		}
	}
}
}
else{
	echo"<h5>Empty Product</h5>";
}
?>

</div>
</div>
<div class="col-md-4 offset-md-1 border-rounded mt-5 bg-white h-25">
<div class="pt-4">
<h6>price</h6>
<hr>
<div class="row price-details">
<div class="row px-6">
<?php
if (isset($_SESSION['cart'])){
	$count=count($_SESSION['cart']);
	echo"<h6>Price ($count itmes) </h6>";
}
else{
	echo"<h6>Price (0 itmes) </h6>";
	
}


?>
</div>
<div class="col-md-6">
<h6>&nbsp &nbsp &nbsp &nbsp<?php echo $total; ?>BDT</h6>
<hr>
<h6>Total &nbsp <?php echo $total; ?>BDT</h6>
</div>
</div>
</div>
</div>

</div>





<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

</body>


<div class="container" id="con">
<h2>About Us</h2>
<div class="row text-center py-5">


<div class="col-md-4 col-sm-6"> 
<h4>Contact Us </h4>
<p>Basundhara,Dhaka</p>
<p>+880-1234567899</p>
<p>email: ecart@gmail.com</p>
</div>

<div class="col-md-4 col-sm-6"> 
<h4>Social Links </h4>

<li><a href="#"><i class="fab fa-facebook"> </i></a></li>
<li><a href="#"><i class="fab fa-twitter"> </i></a></li>
<li><a href="#"><i class="fab fa-instagram"> </i></a></li>
<li><a href="#"><i class="fab fa-youtube"> </i></a></li>
<li><a href="#"><i class="fab fa-whatsapp"> </i></a></li>

</div>


<div class="col-md-4 col-sm-6"> 
<h4>About More </h4>
<div class="add">
                    <button id="new">Click Here</button>
                    <p id="more"></p>
                    <script>
                    document.getElementById('new').addEventListener('click', showText);
       
                    function showText() {
            
                    var req = new XMLHttpRequest();
           
                    req.open('GET', 'cart1.txt', true);
            
                    req.onload = function() {
                    if(req.status==200){
                      document.getElementById('more').innerHTML = req.responseText;
                    }
               
                  }
            
               req.send();

                }

                </script>
                  </div>
</div>


</div>

</footer>
</html>