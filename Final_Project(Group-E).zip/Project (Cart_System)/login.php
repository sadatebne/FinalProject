<?php

session_start();
 

if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"]  === true){
    header("location: cart1.php");
    exit;
}
 
require_once "database.php";
 
$username = $password =  "";
$username_err = $password_err =   "";

  
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }

    
    
    
    if(empty($username_err) && empty($password_err)){
    
        
        
        $sql = "SELECT id, username, password FROM user WHERE username = ? ";
        
        if($stmt = mysqli_prepare($link, $sql)){
           
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            
            $param_username = $username;
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);               
                if(mysqli_stmt_num_rows($stmt) == 1)   
                {                    
                    
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password); 
                    if(mysqli_stmt_fetch($stmt)){
                        //if(password_verify($password, $hashed_password)){
                            if(isset($_REQUEST["remember"]) && $_REQUEST["remember"]==1){
	                            setcookie("login","1",time()+60); 
                             } else{
	                                setcookie("login","1");
                                    header("location:cart1.php");
                             }
                            
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;
                                
                            header("location:cart1.php");
                       
                    }
                } else{
                    
                    $username_err = "No account found with that username.";
                
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }
    
    mysqli_close($link);
}
?>




<!DOCTYPE html>
<html>
 <head>
  <title>EBazer</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  div.container {
  width:500px;
  margin: auto;
  }
  div.panel-heading {
  width:467px;
  margin: auto;
  }
div.form-group {
  width:300px;
  margin: auto;
  
}

div.form-group {
  max-width:300px;
  margin: auto;
  
}
</style>
 </head>
 <body>
  <br />
  <div class="container">
   <h2 align="center">EBazer</h2>
   <br />
   <div class="panel panel-default">

    <div class="panel-heading">Login</div>
    
    <div class="panel-body">
     
     <form method="POST">
     <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                <label>Username</label>
                <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">
                <span class="help-block"><?php echo $username_err; ?></span>
            </div>  
      
      <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
      
      <div class="form-group">
      <input type="submit" class="btn btn-primary" value="Login">
      <input type="checkbox" value="1" name="remember">keep me login:
       <a href="sign_up.php" class="btn btn-success pull-right">Sign Up</a>
       <!--<input type="submit" name="Sign Up" id="Sign Up" class="btn btn-info" value="Sign Up"/>-->
       
       
      </div>
      
      <!--<div class="panel-heading">Sign up</div>-->
     </form>
     <script type="text/javascript">
  function validation(){
  var $username = document.getElementById('username').value;
   var $password = document.getElementById('password').value;
  }
   if($username_err ==""){
    alert("Please enter username");
    return false;
  }
  if($password_err ==""){
    alert("Please enter your password");
  
    return false;
  }
    }
</script>
    
 </body>
</html>