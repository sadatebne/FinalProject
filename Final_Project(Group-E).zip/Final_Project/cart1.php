<?php
session_start();

require_once('cart2.php');

$user='root';
$pass='';
$dbn='ecart';

$db = mysqli_connect("localhost", $user, $pass, $dbn);

$sql="select * from mobile";
$sql2="select * from laptop";
$result= mysqli_query($db, $sql);
$result2= mysqli_query($db, $sql2);

if (isset($_POST['add']))
{
	//print_r($_POST['product_id']);
	if (isset($_SESSION['cart'])){
		$item_array_id=array_column($_SESSION['cart'],"product_id");
		//print_r($item_array_id);
		
		if(in_array($_POST['product_id'],$item_array_id))
		{
			echo"<script> alert('Product already added')</script>";
			echo"<script> window.location=cart1.php </script>";
		}
		else{
			$count=count($_SESSION['cart']);
			$item_array=array(
			'product_id' => $_POST['product_id']
		);
		$_SESSION['cart'][$count]=$item_array;
		//print_r($_SESSION['cart']);
		}
		
	}
	else{
		$item_array=array(
			'product_id' => $_POST['product_id']
		);
		$_SESSION['cart'][0]=$item_array;
		//print_r($_SESSION['cart']);
	}
}
?>



<!DOCTYPE html>
<!html lang ="en">
<head>
<meta charset ="UTF-8">
<title> Shopping Page </title>
<link rel="stylesheet" href="cart.css">
<!--Font Awesome-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

</head>
<body>

<?php
require_once("header.php");
?>
       
<div class="container">
<div><h3 id="s1"><i class="fas fa-mobile"> </i>Mobile Items</h3></div>
<div class="row text-center py-5">
<?php

while($row=mysqli_fetch_assoc($result)){
	 component($row['mobile_name'],$row['mobile_disprice'],$row['mobile_price'],$row['mobile_image'],$row['id']);
	 
}

?>

</div>
</div>


<div class="container">
<div><h3 id="s2"><i class="fas fa-desktop"> </i>Laptop Items</h3></div>
<div class="row text-center py-5">


<?php

while($row=mysqli_fetch_assoc($result2)){
	 component($row['laptop_name'],$row['laptop_disprice'],$row['laptop_price'],$row['laptop_image'],$row['id']);
	 
}

?>

</div>
</div>




<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>


</body>


<footer>


<div class="container" id="con">
<h2>About Us</h2>
<div class="row text-center py-5">
<div class="col-md-4 col-sm-6"> 
<div>
<h4>Contact </h4>
<button id="get" >Contact Info</button>
 <div id="universities"></div>
    <script>

    document.getElementById('get').addEventListener('click', showValues);
    function showValues() {
        var req = new XMLHttpRequest();
        req.open('GET','return.php',true );

        req.onload = function(){
            if(req.status==200){
            var namez = JSON.parse(req.responseText);
            var display = '';
           
            for (var i in namez){
                display += '<ul>'+
                    '<li>Address: '+namez[i].address+'</li>'+
                    '<li>Phone-No: '+namez[i].phoneno+'</li>'+
                    '<li>Email: '+namez[i].email+'</li>'+'</ul>';
            }

           
            document.getElementById('universities').innerHTML=display;
        }
    }
        req.send();
    }
    </script>
	</div>

</div>


<div class="col-md-4 col-sm-6"> 
<h4>Social Address </h4>

<li><a href="#"><i class="fab fa-facebook"> </i></a></li>
<li><a href="#"><i class="fab fa-twitter"> </i></a></li>
<li><a href="#"><i class="fab fa-instagram"> </i></a></li>
<li><a href="#"><i class="fab fa-youtube"> </i></a></li>
<li><a href="#"><i class="fab fa-whatsapp"> </i></a></li>

</div>
<div class="col-md-4 col-sm-6"> 
<h4>About More </h4>
<div class="add">
                    <button id="data">Message For Customer</button>
                    <p id="more"></p>
                    <script>
                    document.getElementById('data').addEventListener('click', showText);
       
                    function showText() {
            
                    var req = new XMLHttpRequest();
           
                    req.open('GET', 'cart.txt', true);
            
                    req.onload = function() {
                    if(req.status==200){
                      document.getElementById('more').innerHTML = req.responseText;
                    }
               
                  }
            
               req.send();

                }

                </script>
                  </div>
</div>


</div>

</footer>
</html>