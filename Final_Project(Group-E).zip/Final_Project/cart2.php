<?php
function component($productname,$productdiscount,$productprice,$productimg,$productid){
$element=
  "
  <div class=\"col-md-3 col-sm-6 my-3 my-md-0\" >
  <form action=\"cart1.php\" method=\"POST\">
  <div class=\"card shadow\">
  <div>
  <img src=\"$productimg\" alt=\"Mobile\" class=\"img-fluid card-img-top\">
  </div>
  <div class=\"card-body\">
 <h5 class=\"card-title\" >$productname</h5> 
  <h6>
    <i class=\"fas fa-star\"> </i>
	<i class=\"fas fa-star\"> </i>
	<i class=\"fas fa-star\"> </i>
	<i class=\"fas fa-star\"> </i>
	<i class=\"far fa-star\"> </i>
	
  </h6>
  <p class=\"card-text\">This Product is good </p>
  <h5> 
  <small><s>$productdiscount BDT</s></small>
  <span class=\"price\"> $productprice BDT</span> 
  </h5>
  
  <button type=\"submit\" class =\"btn btn-warning my-3\" Name=\"add\">Add to Cart <i class=\"fas fa-shopping-cart\"> </i> </button>
  <input type='hidden' name='product_id' value='$productid'>
  </div>
  </div>
  </form>
  </div>
";


echo $element;
}



//./images/mobile.png


function C_Element($productimg,$productname,$productprice,$productid){
	$element="
	<form action=\"display.php?action=remove&id=$productid\" method=\"post\" class=\"C_items\" >
<div class=\"border rounded\">
<div class=\"row bg-white\">
<div class=\"col-md-3\">
<img src=\"$productimg\" alt=\"images1\" class=\"img-fluid\">
</div>
<div class=\"col-md-6\">
<h5 class=\"pt-2\">$productname</h5>
<small class=\"text-seconday\">mobie xiaomi </small>
<h5 class=\"pt-2\">$productprice</h5>
<button type=\"submit\" class=\"btn btn-danger mx-2\" name=\"remove\"> Remove </button>


</div>
<div class=\"col-md-3\">
<div>
<button type=\"button\" class=\"btn bg-ligth border rounded-circle\"><i class=\"fas fa-minus\"></i></button>
<input type=\"text\" value=\"1\" class=\"form-control w-25 d-inline\">
<button type=\"button\" class=\"btn bg-ligth border rounded-circle\"><i class=\"fas fa-plus\"></i></button>
</div>
</div>



</div>
</div>
</form>
" ;
	echo $element;
}
function checkout(){
	$element="
<form action=\"Payment.php?action=CHEKOUT\" method=\"post\" class=\"C_items\" >
<div class=\"border rounded\">
<div class=\"row bg-white\">
<div class=\"col-md-12\">
                      <center><button type=\"submit\" class=\"btn btn-warning\"> CHECKOUT </button></center>
<div class=\"col-md-3\">
</div>
<div>
</div>
</div>
</div>
</div>
</form>
";
echo $element;
}







