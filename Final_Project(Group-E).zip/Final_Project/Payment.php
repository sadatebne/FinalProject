<?php
include "head.php"
?>
<html>
<head></head>
<body>
<font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">
                                     
                                    
<center><h1><i>Payment Option</i></h1></center>
<center> <ul>

					<li><a href="bkash.php"><b><h3><u><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">Bkash</font><u></h3></b></a></li>
					</font>
					<li><a href="#"><b><h3><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">Rocket</font></h3></b></a></li>
					<li><a href="#"><b><h3><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">Nogod</font></h3></b></a></li>
					<li><a href="#"><b><h3><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">Card</font></h3></b></a></li>
				<br>
				<br>
				<li><a href="home.php"><b><h3><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">GO TO HOMEPAGE</font></h3></b></a></li>
									
					</ul></center>
</font>
</body>
</html>
<?php
include "footer.php"
?>