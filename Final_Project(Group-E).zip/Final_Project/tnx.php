<?php
include "head.php"
?>
<html>
<div class="container" id="con">
<div class="row text-center py-5">


<div class="col-md-4 col-sm-6"> 

</div>

<div class="col-md-4 col-sm-6"> 

</div>


<div class="col-md-4 col-sm-6"> 
<h1 style ="color:yellow"> PAYMENT SUCCESSFUL </h1>
<div class="add">
                    <button id="new">Message For You</button>
                    <p id="more"></p>
                    <script>
                    document.getElementById('new').addEventListener('click', showText);
       
                    function showText() {
            
                    var req = new XMLHttpRequest();
           
                    req.open('GET', 'cart1.txt', true);
            
                    req.onload = function() {
                    if(req.status==200){
                      document.getElementById('more').innerHTML = req.responseText;
                    }
               
                  }
            
               req.send();

                }

                </script>
				
				<a href="home.php"><b><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">GO TO HOMEPAGE</font></b></a>
                  </div>
</div>
</html>