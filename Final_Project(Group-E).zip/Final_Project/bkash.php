
<?php
include "head.php";
   $datab =mysqli_connect('localhost'  ,'root' , '' , 'ecart');
 if(isset($_POST['submit_button'])) {
    $name = $_POST['name'];
    $address = $_POST['address'];
  
	$id='';
	$dateb=$_POST['date'];
	$ammount=$_POST['ammount'];
	$bk =$_POST['bk'];
    $sql = "INSERT INTO bkash(id,name, address, bnumber,db,ammount) VALUES('$id' , '$name', '$address', '$bk','$dateb', '$ammount')";
    mysqli_query($datab, $sql);

}
?>


<html>
<title> Bkash payment method    </title>
<head><h2><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif"> Bkash payment method</font></h2></head>
<body>  

<form method="post" action="tnx.php">
<table> 
<tr>
<td><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">Name</font></dt>
<td> <input type="text" name="name"</td>
</tr>
<br>

<tr>
<td><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">address</font></dt>
<td> <input type="address" name="address"</td>
</tr>

<tr>
<td><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">bkash number</font></dt>
<td> <input type="text"  name="bk"</td>
</tr>

<tr>
<td><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">Date</font></dt>
<td> <input type="date" name="date"</td>
</tr>

<tr>
<td><font style="font-style:normal; font-size: 33px;color: aliceblue;font-family: serif">ammount</font></dt>
<td> <input type="text" name="ammount"</td>
</tr>
<tr>

<td> <input type="submit" name="submit_button" value="SEND"</td>
</tr>

</table>
</body>

</form>

</html>
<?php
include "footer.php";
?>