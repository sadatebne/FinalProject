<html>
<body>

Welcome <?php echo 
$_GET["msg"]
; ?>

</body>
</html>